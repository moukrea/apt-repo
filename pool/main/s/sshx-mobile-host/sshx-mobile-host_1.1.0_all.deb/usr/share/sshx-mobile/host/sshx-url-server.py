#!/usr/bin/env python3
"""sshx-url-server.py - tiny stdlib HTTP resolver for the current sshx URL.

Serves two routes (the self-hosted resolver profile of ADR 0001):

    GET  /current-url   ->  200 text/plain   the current sshx session URL
                            404 text/plain   if no URL is available yet
    POST /current-url   ->  200 text/plain   accepts the URL (raw body) and writes
                            the file atomically (so a host pushes the current URL
                            here, and a phone reads it back)
                            400 text/plain   if the body has no valid sshx URL

The file is read FRESH on every GET (no caching) so a phone always gets the URL
of the live session, even after sshx.service restarted and minted a new one. The
POST body is tolerated as a raw URL OR a JSON-quoted string "<url>" (the host's
resolver_client may send either, matching the MantleDB profile shape); the URL is
extracted with the RESOLVER CONTRACT regex.

PRIVACY: the URL fragment after '#' is the end-to-end decryption KEY. This server
returns it in plaintext, so it MUST be reachable ONLY over a trusted network you
control (LAN / Tailscale / WireGuard). Never expose it to the public internet.
The same goes for POST: anyone who can POST here can hijack which session the
phone connects to, so the network MUST be trusted (set SSHX_RESOLVER_TOKEN to add
a shared-secret header check if the network is not fully trusted).

Config via environment (set by sshx-resolver.service):
    SSHX_URL_FILE        path to the current-url file
                         (default: ~/.local/share/sshx/current-url)
    SSHX_RESOLVER_PORT   TCP port (default: 8765)
    SSHX_RESOLVER_BIND   bind address (default: 0.0.0.0; set to a Tailscale IP to
                         restrict exposure to the overlay network)
    SSHX_RESOLVER_TOKEN  optional shared secret; if set, POST must send it in the
                         X-Mantle-Key header (GET stays open, the value is a
                         capability anyway). Empty => no POST auth (trusted net).

Stdlib only - no third-party dependencies.
"""

import os
import re
import sys
import tempfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DEFAULT_URL_FILE = os.path.join(
    os.path.expanduser("~"), ".local", "share", "sshx", "current-url"
)
URL_FILE = os.environ.get("SSHX_URL_FILE", DEFAULT_URL_FILE)
PORT = int(os.environ.get("SSHX_RESOLVER_PORT", "8765"))
BIND = os.environ.get("SSHX_RESOLVER_BIND", "127.0.0.1")
TOKEN = os.environ.get("SSHX_RESOLVER_TOKEN", "").strip()
TOKEN_HEADER = "X-Mantle-Key"

# Largest POST body we will read (a URL is tiny; cap to avoid abuse).
MAX_BODY = 8192

# Match an sshx session URL anywhere in the file (the file may contain blank
# lines or, with --enable-readers, several URL lines - we serve the FIRST, which
# is the editor URL). Stop at whitespace and at a double-quote so a JSON-quoted
# POST body "<url>" yields the bare URL.
_URL_RE = re.compile(r'https?://[^\s"]+/s/[^\s"#]+#[^\s"]+')


def read_current_url():
    """Return the current session URL from the file, or None if unavailable."""
    try:
        with open(URL_FILE, "r", encoding="utf-8", errors="replace") as fh:
            data = fh.read()
    except OSError:
        return None
    m = _URL_RE.search(data)
    return m.group(0) if m else None


def write_current_url(url):
    """Write `url` to the file atomically (temp file + rename), mode 0600.

    Atomic so a concurrent GET never reads a half-written file: it sees either
    the old URL or the new one, never a torn value."""
    d = os.path.dirname(URL_FILE) or "."
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".current-url.")
    try:
        os.fchmod(fd, 0o600)
        os.write(fd, (url + "\n").encode("utf-8"))
        os.close(fd)
        os.replace(tmp, URL_FILE)  # atomic on the same filesystem
    except BaseException:
        try:
            os.close(fd)
        except OSError:
            pass
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


class ResolverHandler(BaseHTTPRequestHandler):
    server_version = "sshx-url-server/2.0"

    def _send(self, code, body, content_type="text/plain; charset=utf-8"):
        payload = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        # Never let an intermediary or the client cache a stale URL.
        self.send_header("Cache-Control", "no-store")
        self.send_header("Pragma", "no-cache")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(payload)

    def _path(self):
        # Strip any query string; compare path only (trailing slash tolerated).
        return self.path.split("?", 1)[0].rstrip("/")

    def _route_get(self):
        if self._path() == "/current-url":
            url = read_current_url()
            if url:
                # Return the URL as DATA (body), never a 302 redirect: a redirect
                # would drop the '#fragment' that carries the E2E key.
                self._send(200, url + "\n")
            else:
                self._send(404, "no current sshx URL available yet\n")
            return
        self._send(404, "not found; try GET or POST /current-url\n")

    def do_GET(self):
        self._route_get()

    def do_HEAD(self):
        self._route_get()

    def do_POST(self):
        if self._path() != "/current-url":
            self._send(404, "not found; try POST /current-url\n")
            return
        # Optional shared-secret check (only enforced if SSHX_RESOLVER_TOKEN set).
        if TOKEN and self.headers.get(TOKEN_HEADER, "") != TOKEN:
            self._send(403, "forbidden\n")
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0 or length > MAX_BODY:
            self._send(400, "missing or oversized body\n")
            return
        raw = self.rfile.read(length).decode("utf-8", errors="replace")
        # Tolerate a raw URL OR a JSON-quoted string "<url>".
        m = _URL_RE.search(raw)
        if not m:
            self._send(400, "no valid sshx URL in body\n")
            return
        url = m.group(0)
        try:
            write_current_url(url)
        except OSError as exc:
            self._send(500, "could not store URL: %s\n" % exc)
            return
        self._send(200, "ok\n")

    # Quieter, single-line logging to stderr (journal under systemd). NEVER log
    # the request path beyond the route (the body holds the #key; we don't log it
    # and the URL never appears in the request line).
    def log_message(self, fmt, *args):
        sys.stderr.write(
            "%s - %s\n" % (self.address_string(), fmt % args)
        )


def main():
    httpd = ThreadingHTTPServer((BIND, PORT), ResolverHandler)
    sys.stderr.write(
        "sshx-url-server: serving GET/POST /current-url on http://%s:%d (file: %s)\n"
        % (BIND, PORT, URL_FILE)
    )
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
