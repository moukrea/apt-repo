#!/usr/bin/env python3
"""sshx_health.py - liveness probe for the current sshx session.

Detects the "stale session" failure mode: sshx.io has expired or forgotten the
session (long idle, a network drop, a half-open TCP after suspend) while the
local `sshx` process still believes it is connected - so it never exits, never
re-mints a URL, and the resolver keeps serving a DEAD url. The app then shows a
blank/black screen. Rotation hid this (it restarts sshx on a timer) but did not
fix the root cause when rotation is off.

The probe replicates EXACTLY what the phone does to reach a session: open a
WebSocket to

    <ws-scheme>://<host>/api/s/<id>

and read the FIRST server frame. The sshx server (ekzhang/sshx,
crates/sshx-server/src/web/socket.rs) answers one of:

  - a CLOSE frame with application code 4404 ("could not find the requested
    session")  => the session is GONE (dead/stale);
  - a DATA frame (the WsServer::Hello message)  => the session EXISTS (alive).

The Hello is sent BEFORE the client must authenticate, so this probe needs
NEITHER the '#key' (the E2E secret in the URL fragment, which we never send) NOR
any CBOR decoding - it only inspects the WebSocket frame opcode and close code.
And because we disconnect before ever sending WsClient::Authenticate, the server
never registers a user (user_scope is gated behind auth), so the probe is
invisible to other clients: no ghost-user flicker in the app's presence list.

probe() returns one of:
    "alive"    the session is reachable (Hello received);
    "dead"     the server explicitly reported the session as not found (4404);
    "unknown"  network error / non-101 / inconclusive - NEVER treated as dead,
               so a brief offline window cannot trigger a needless restart.

Stdlib only (socket, ssl, base64, os, struct). Runnable standalone for
debugging:

    python3 sshx_health.py "https://sshx.io/s/<id>#<key>"   # prints alive/dead/unknown

PRIVACY: only the '/s/<id>' path is used to build the '/api/s/<id>' endpoint;
the '#key' fragment never leaves this process and is never logged.
"""
import base64
import os
import socket
import ssl
import struct
import sys
from urllib.parse import urlparse

ALIVE, DEAD, UNKNOWN = "alive", "dead", "unknown"

# Close code the sshx server sends when the session name is not found. It is an
# application close code (the 4000-4999 range is reserved for app use), so it is
# unambiguous and stable across sshx releases.
NOT_FOUND_CLOSE_CODE = 4404

# Hard caps so a malformed/hostile frame can never make us read unbounded data.
_MAX_FRAME = 1 << 20
_MAX_HEADERS = 1 << 16


def _session_id(path):
    """Extract <id> from an sshx URL path '/s/<id>' (tolerates a trailing slash
    and a leading prefix). The WS endpoint is then '/api/s/<id>'."""
    parts = [p for p in path.split("/") if p]
    if "s" in parts:
        i = parts.index("s")
        if i + 1 < len(parts):
            return parts[i + 1]
    return parts[-1] if parts else ""


def _take(sock, buf, n):
    """Return (n bytes, remaining buffer), reading from the socket as needed."""
    while len(buf) < n:
        chunk = sock.recv(4096)
        if not chunk:
            raise OSError("websocket closed before the frame was complete")
        buf.extend(chunk)
    return bytes(buf[:n]), buf[n:]


def _read_first_frame(sock, leftover, max_frames=8):
    """Read frames until the first DATA or CLOSE frame; skip control noise
    (ping/pong). Returns ALIVE / DEAD / UNKNOWN. Server->client frames are not
    masked, but we tolerate a mask bit defensively."""
    buf = bytearray(leftover)
    for _ in range(max_frames):
        hdr, buf = _take(sock, buf, 2)
        opcode = hdr[0] & 0x0F
        masked = (hdr[1] & 0x80) != 0
        length = hdr[1] & 0x7F
        if length == 126:
            ext, buf = _take(sock, buf, 2)
            length = struct.unpack(">H", ext)[0]
        elif length == 127:
            ext, buf = _take(sock, buf, 8)
            length = struct.unpack(">Q", ext)[0]
        if length > _MAX_FRAME:
            return UNKNOWN
        mask = b""
        if masked:
            mask, buf = _take(sock, buf, 4)
        payload = b""
        if length:
            payload, buf = _take(sock, buf, length)
        if masked and mask:
            payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))

        if opcode == 0x8:  # CLOSE
            if len(payload) >= 2:
                code = struct.unpack(">H", payload[:2])[0]
                return DEAD if code == NOT_FOUND_CLOSE_CODE else UNKNOWN
            return UNKNOWN
        if opcode in (0x1, 0x2):  # TEXT / BINARY data = Hello = the session exists
            return ALIVE
        # opcode 0x0/0x9/0xA (continuation/ping/pong): ignore and read the next frame
    return UNKNOWN


def probe(url, timeout=8.0):
    """Return ALIVE / DEAD / UNKNOWN for an sshx session URL. Only the path is
    used; the '#key' fragment is never sent over the wire."""
    try:
        u = urlparse(url)
    except Exception:  # noqa: BLE001 - any parse failure is just "inconclusive"
        return UNKNOWN
    host = u.hostname
    if not host:
        return UNKNOWN
    secure = u.scheme in ("https", "wss")
    port = u.port or (443 if secure else 80)
    sid = _session_id(u.path)
    if not sid:
        return UNKNOWN
    ws_path = "/api/s/" + sid

    key = base64.b64encode(os.urandom(16)).decode("ascii")
    handshake = (
        "GET %s HTTP/1.1\r\n"
        "Host: %s\r\n"
        "Upgrade: websocket\r\n"
        "Connection: Upgrade\r\n"
        "Sec-WebSocket-Key: %s\r\n"
        "Sec-WebSocket-Version: 13\r\n"
        "\r\n"
    ) % (ws_path, host, key)

    sock = None
    try:
        sock = socket.create_connection((host, port), timeout=timeout)
        if secure:
            ctx = ssl.create_default_context()
            sock = ctx.wrap_socket(sock, server_hostname=host)
        sock.settimeout(timeout)
        sock.sendall(handshake.encode("ascii"))

        # Read the HTTP upgrade response head.
        buf = bytearray()
        while b"\r\n\r\n" not in buf:
            chunk = sock.recv(4096)
            if not chunk:
                return UNKNOWN
            buf.extend(chunk)
            if len(buf) > _MAX_HEADERS:
                return UNKNOWN
        status_line = bytes(buf).split(b"\r\n", 1)[0]
        if b" 101 " not in status_line:
            # No upgrade (4xx/5xx, or a proxy error): says nothing about the
            # session itself, so do not call it dead.
            return UNKNOWN
        head_end = bytes(buf).index(b"\r\n\r\n") + 4
        leftover = buf[head_end:]
        return _read_first_frame(sock, leftover)
    except (OSError, ssl.SSLError, ValueError):
        return UNKNOWN
    finally:
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        sys.stderr.write("usage: sshx_health.py <sshx-url>\n  prints: alive | dead | unknown\n")
        return 2
    print(probe(argv[0]))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
