#!/usr/bin/env python3
"""resolver_client.py - backend-agnostic client for the sshx URL resolver.

The resolver gives the app a STABLE address that always returns the CURRENT
(volatile) sshx session URL. This module is the host side of that contract:

    push(url)   POST the sshx URL to the resolver (so the app can read it).
    read()      GET the current sshx URL back from the resolver.

It is backend-agnostic per ADR 0001: it only knows about a PUSH url, a READ url,
an optional password header, and whether the body is raw or JSON-quoted. The two
shipped profiles (MantleDB non-claim, self-hosted sshx-url-server.py) are just
two sets of env values; the code is identical for both. See resolver.env.example.

Config via environment:
    RESOLVER_PUSH_URL        where to POST the URL (empty => push is a no-op).
    RESOLVER_READ_URL        where to GET the URL (defaults to PUSH_URL).
    RESOLVER_PASSWORD        optional secret sent as a header on push and read.
    RESOLVER_PASSWORD_HEADER header name for the password (default X-Mantle-Key).
    RESOLVER_JSON_BODY       1 => push the body as a JSON object {"url": "<url>"}
                             (MantleDB); read tolerates raw/JSON-quoted/object bodies.
                             0 => raw body (self-hosted server). Default 0.

PRIVACY: the URL contains the sshx '#key', the end-to-end decryption key. This
module NEVER logs the full URL. Callers must keep the resolver private (trusted
network and/or password header). See PRD section 9.

Stdlib only. Importable by sshx_spawn.py, and runnable for manual testing:

    python3 resolver_client.py push "https://sshx.io/s/<id>#<key>"
    python3 resolver_client.py read
"""

import json
import os
import re
import sys
import urllib.error
import urllib.request

# Default header name matches the MantleDB profile; overridable per ADR 0001.
DEFAULT_PASSWORD_HEADER = "X-Mantle-Key"

# Tolerant matcher: extract an sshx URL from a raw OR JSON-quoted body. Stops at
# whitespace and at a double-quote so a JSON-wrapped value "<url>" yields the URL
# without the surrounding quotes. Matches the RESOLVER CONTRACT regex.
_URL_RE = re.compile(r'https?://[^\s"]+/s/[^\s"#]+#[^\s"]+')

# Network timeout for resolver calls; the resolver is small and local-ish.
TIMEOUT = float(os.environ.get("RESOLVER_TIMEOUT", "5"))

# Some hosted resolvers (e.g. MantleDB) reject the default "Python-urllib/x.y" User-Agent with
# 403, so send an explicit one on every request.
USER_AGENT = "sshx-resolver/1"


def _cfg():
    """Read resolver config from the environment (re-read per call: cheap, and
    keeps the module stateless / testable)."""
    push_url = os.environ.get("RESOLVER_PUSH_URL", "").strip()
    read_url = os.environ.get("RESOLVER_READ_URL", "").strip() or push_url
    password = os.environ.get("RESOLVER_PASSWORD", "").strip()
    header = os.environ.get("RESOLVER_PASSWORD_HEADER", "").strip() or DEFAULT_PASSWORD_HEADER
    json_body = os.environ.get("RESOLVER_JSON_BODY", "0").strip() in ("1", "true", "yes", "on")
    return push_url, read_url, password, header, json_body


def extract_url(text):
    """Return the sshx URL found in `text` (raw or JSON-quoted), or None."""
    if not text:
        return None
    m = _URL_RE.search(text)
    return m.group(0) if m else None


def redact(url):
    """Return a loggable form of the URL: the '/s/<id>' part only, with the
    '#key' fragment redacted. NEVER returns the key. Safe for logs."""
    if not url:
        return "<no-url>"
    m = re.search(r"/s/[^\s/?#]+", url)
    sid = m.group(0) if m else "/s/?"
    return sid + "#<redacted>"


def push(url):
    """POST `url` to the resolver. Returns True on success, False on failure.

    If RESOLVER_PUSH_URL is empty, this is a no-op returning False (the caller
    is then in file-only mode and should log that)."""
    push_url, _read_url, password, header, json_body = _cfg()
    if not push_url:
        return False
    if json_body:
        # MantleDB stores one JSON OBJECT per path and rejects a bare JSON string with 400, so wrap
        # the URL: {"url": "<url>"}. The reader extracts the URL by regex, so the key name is free.
        body = json.dumps({"url": url}).encode("utf-8")
        content_type = "application/json"
    else:
        body = url.encode("utf-8")
        content_type = "text/plain; charset=utf-8"
    req = urllib.request.Request(push_url, data=body, method="POST")
    req.add_header("Content-Type", content_type)
    req.add_header("User-Agent", USER_AGENT)
    if password:
        req.add_header(header, password)
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        # Any 2xx is success; urlopen raises on >=400 so reaching here is good.
        return 200 <= resp.status < 300


def read():
    """GET the current sshx URL from the resolver. Returns the URL string, or
    None if unavailable / unparseable. Tolerates raw and JSON-quoted bodies."""
    _push_url, read_url, password, header, _json_body = _cfg()
    if not read_url:
        return None
    req = urllib.request.Request(read_url, method="GET")
    req.add_header("User-Agent", USER_AGENT)
    if password:
        req.add_header(header, password)
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            data = resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        # 404 = not published yet; 401/403 = wrong/missing password header. In all of these the
        # current URL is simply unavailable, so return None rather than raising (a wrong password
        # is a config mistake, not a crash). Other codes (5xx) still propagate.
        if exc.code in (401, 403, 404):
            return None
        raise
    return extract_url(data)


def _main(argv):
    if len(argv) < 1 or argv[0] in ("-h", "--help"):
        sys.stderr.write(
            "usage: resolver_client.py push <url> | read\n"
            "  push <url>  POST the sshx URL to the resolver\n"
            "  read        GET the current sshx URL from the resolver\n"
        )
        return 2
    cmd = argv[0]
    if cmd == "push":
        if len(argv) < 2:
            sys.stderr.write("push: missing <url>\n")
            return 2
        url = argv[1]
        # Log only the redacted form; never the '#key'.
        ok = push(url)
        if ok:
            sys.stderr.write("push: ok %s\n" % redact(url))
            return 0
        sys.stderr.write("push: no-op (RESOLVER_PUSH_URL is empty)\n")
        return 1
    if cmd == "read":
        url = read()
        if url:
            # The read subcommand is for manual testing: print the URL to stdout
            # so a human/script can use it. (Logs to stderr stay redacted.)
            sys.stdout.write(url + "\n")
            return 0
        sys.stderr.write("read: no current URL available\n")
        return 1
    sys.stderr.write("unknown command: %s (try --help)\n" % cmd)
    return 2


if __name__ == "__main__":
    sys.exit(_main(sys.argv[1:]))
