# claude-tmux.sh - run `claude` so the session ALSO lives in the sshx tmux `main` session, where
# sshx-mobile can reach it from the phone. Source this from ~/.bashrc.
#
# A normal `claude <args>` typed in a host terminal is launched in a NEW window of the sshx tmux
# server (-L sshx, session `main`) and the current terminal is attached to it, so it behaves exactly
# like running claude locally - except the session now lives in tmux and is reachable from the phone:
#   - Exit claude normally -> its window dies and the window-unlinked reaper detaches us straight
#     back to this shell ("recatchup dans le terminal courant").
#   - Just detach / close the terminal instead -> claude keeps running in the background tmux window.
#   - Join from the phone app -> sshx-tmux-shell sees this window's HOST marker (an hx<id> session)
#     and CO-VIEWS it as a tab, so you interact with the same claude session from the phone.
#
# Already inside the sshx tmux server (e.g. a shell opened from the phone)? It just runs claude in
# place - no nested window/attach.
#
# Robustness: if the window can't be created it falls back to running claude locally so it NEVER
# breaks the command. The sshx tmux server + a configured `main` are created on demand if missing
# (so it works even right after the server was killed).
claude() {
    local sock="sshx" base="main" conf="${HOME}/.config/sshx/tmux.sshx.conf" real
    real="$(type -P claude)"
    if [ -z "$real" ]; then
        echo "claude: real binary not found in PATH" >&2
        return 127
    fi

    # Inside the sshx tmux server already ($TMUX = "<sockpath>,<pid>,<session>"): run it here.
    case "${TMUX%%,*}" in
        */"$sock") "$real" "$@"; return $? ;;
    esac

    # Ensure the sshx tmux server + a CONFIGURED base session exist (create on demand). Loading the
    # conf matters: it carries the colors, scroll bindings and the window-unlinked reaper hook this
    # helper relies on. Never fall back to local just because the server was down.
    if ! tmux -L "$sock" has-session -t "$base" 2>/dev/null; then
        tmux -L "$sock" start-server 2>/dev/null
        [ -f "$conf" ] && tmux -L "$sock" source-file "$conf" 2>/dev/null
        tmux -L "$sock" new-session -d -s "$base" 2>/dev/null
    fi
    if ! tmux -L "$sock" has-session -t "$base" 2>/dev/null; then
        echo "claude: sshx tmux unavailable, running locally" >&2
        "$real" "$@"
        return $?
    fi

    # Launch claude in a fresh `main` window in the current directory, sourcing the login env so it
    # matches a normal interactive shell. %q-quote so args with spaces/specials survive the
    # tmux -> sh -> bash -> exec hops.
    local qcmd boot win
    printf -v qcmd '%q ' "$real" "$@"
    boot="source ~/.bash_profile 2>/dev/null; source ~/.bashrc 2>/dev/null; exec ${qcmd}"
    win="$(tmux -L "$sock" new-window -t "$base" -P -F '#{window_id}' -c "$PWD" \
        "bash -c $(printf '%q' "$boot")" 2>/dev/null)"
    if [ -z "$win" ]; then
        echo "claude: could not create tmux window, running locally" >&2
        "$real" "$@"
        return $?
    fi
    tmux -L "$sock" set-window-option -t "$win" automatic-rename off 2>/dev/null
    tmux -L "$sock" rename-window -t "$win" "claude:${PWD##*/}" 2>/dev/null

    # HOST view session hx<id> locked to the claude window. The DISTINCT hx prefix (vs the phone's
    # sx<id>) tells sshx-tmux-shell this is a host window it should CO-VIEW, so the claude session
    # surfaces as a phone tab. We do NOT set @owner_pid (that would mark it phone-owned and make the
    # phone skip it). The window-unlinked reaper kills hx<id> when claude exits, detaching us back to
    # this shell; if we just detach, hx<id> persists so the phone can still find the running session.
    local vs="hx${win#@}"
    tmux -L "$sock" new-session -d -t "$base" -s "$vs" 2>/dev/null
    tmux -L "$sock" set-option -t "$vs" @locked_window "$win" 2>/dev/null
    tmux -L "$sock" set-option -t "$vs" @host_pid "$$" 2>/dev/null
    tmux -L "$sock" select-window -t "${vs}:${win}" 2>/dev/null
    TMUX= tmux -L "$sock" attach-session -t "$vs"
    return 0
}
