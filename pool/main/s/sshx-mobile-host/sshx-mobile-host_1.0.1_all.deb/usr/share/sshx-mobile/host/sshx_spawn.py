#!/usr/bin/env python3
"""sshx_spawn.py - spawn one disposable sshx session and publish its URL.

This is the host-core supervisor run under sshx.service (Restart=always). Per the
PRD and PLAN (I1.E2.S1), each invocation:

  1. spawns `sshx -q` (the bin is configurable via SSHX_BIN);
  2. captures the printed session URL https://sshx.io/s/<id>#<key>;
  3. pushes it to the resolver via resolver_client (skipped if no push URL set);
  4. ALSO writes it to ~/.local/share/sshx/current-url (truncated first), so the
     self-hosted resolver / sshx-qr / sshx-session all read the same file;
  5. WAITS for the sshx child and exits with its exit code.

Because we exit with sshx's code, systemd (Restart=always) respawns sshx, which
mints a NEW URL, which we capture and re-publish. The tmux server lives in its
OWN unit (separate cgroup) so this respawn never touches the session state.

Re-pushing the same URL on a slow timer is NOT done here: a separate rotation
timer (sshx-rotate) handles refresh by restarting this service.

On SIGTERM (systemd stop / restart) we terminate the sshx child cleanly, then
let it propagate.

PRIVACY (PRD section 9): the URL contains the sshx '#key' (E2E decryption key).
This script NEVER logs the full URL: logs show only the '/s/<id>' part with the
'#key' redacted. The current-url file holds the full URL but is private to the
user and read only over a trusted network / the local resolver.

Config via environment:
    SSHX_BIN                  path to sshx (default: /usr/local/bin/sshx).
    SSHX_URL_FILE             current-url file (default ~/.local/share/sshx/current-url).
    SSHX_EXTRA_ARGS           optional extra args for sshx, shell-split (e.g.
                              "--name host --enable-readers").
    RESOLVER_PUSH_URL         resolver push endpoint; empty => file-only mode.
    RESOLVER_PASSWORD         optional resolver secret.
    RESOLVER_PASSWORD_HEADER  resolver password header (default X-Mantle-Key).
    RESOLVER_JSON_BODY        1 => JSON-quoted body (MantleDB), 0 => raw. Default 0.
    (see resolver_client.py / resolver.env.example for the resolver profiles.)

Stdlib only.
"""

import os
import re
import shlex
import signal
import sys
import threading

import resolver_client

def _resolve_sshx_bin():
    # Explicit override wins; then PATH (systemd --user PATH is /usr/local/bin:/usr/bin:/bin); then
    # common install locations - official installer -> /usr/local/bin, cargo -> ~/.cargo/bin, manual
    # tarball -> ~/.local/bin. Fall back to /usr/local/bin/sshx for a clear "not found" error.
    env = os.environ.get("SSHX_BIN")
    if env:
        return env
    import shutil
    found = shutil.which("sshx")
    if found:
        return found
    for cand in ("/usr/local/bin/sshx",
                 os.path.expanduser("~/.cargo/bin/sshx"),
                 os.path.expanduser("~/.local/bin/sshx")):
        if os.path.isfile(cand) and os.access(cand, os.X_OK):
            return cand
    return "/usr/local/bin/sshx"


SSHX_BIN = _resolve_sshx_bin()
DEFAULT_URL_FILE = os.path.join(
    os.path.expanduser("~"), ".local", "share", "sshx", "current-url"
)
URL_FILE = os.environ.get("SSHX_URL_FILE", DEFAULT_URL_FILE)

# By default sshx serves a NATIVE tmux client (the sshx-tmux-shell wrapper attaches the persistent
# tmux session), so the phone gets a faithful, interactive, LOSSLESS terminal that sshx renders
# itself. Override with SSHX_SHELL=<cmd>, or SSHX_SHELL= (empty) for the plain login shell.
DEFAULT_TMUX_SHELL = os.path.join(
    os.path.expanduser("~"), ".local", "bin", "sshx-tmux-shell"
)
SSHX_SHELL = os.environ.get("SSHX_SHELL", DEFAULT_TMUX_SHELL)

# An sshx session URL printed on stdout. Same shape the resolver matches.
_URL_RE = re.compile(r"https?://[^\s]+/s/[^\s#]+#[^\s]+")

# Module-level handle so the SIGTERM handler can reach the child.
_child = None
_child_lock = threading.Lock()


def log(msg):
    """Single-line log to stderr (journal under systemd). NEVER pass a full
    URL here: use resolver_client.redact() first."""
    sys.stderr.write("sshx_spawn: %s\n" % msg)
    sys.stderr.flush()


def write_url_file(url):
    """Truncate the current-url file and write the single current URL.

    Truncate-first guarantees the file only ever holds the CURRENT session's URL
    (matches sshx.service's ExecStartPre truncate semantics)."""
    d = os.path.dirname(URL_FILE)
    if d:
        os.makedirs(d, exist_ok=True)
    # Open with 'w' (truncate) then write; chmod 600 since it holds the #key.
    fd = os.open(URL_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, (url + "\n").encode("utf-8"))
    finally:
        os.close(fd)


def publish(url):
    """Write the URL to the file and push it to the resolver. Logs redacted."""
    try:
        write_url_file(url)
        log("wrote current-url file %s" % resolver_client.redact(url))
    except OSError as exc:
        log("ERROR writing current-url file: %s" % exc)

    if not os.environ.get("RESOLVER_PUSH_URL", "").strip():
        log("file-only mode: RESOLVER_PUSH_URL is empty, skipping resolver push")
        return
    try:
        ok = resolver_client.push(url)
        if ok:
            log("pushed to resolver %s" % resolver_client.redact(url))
        else:
            log("resolver push returned no success for %s" % resolver_client.redact(url))
    except Exception as exc:  # noqa: BLE001 - never let a resolver hiccup kill us
        # A failed push must not take down the session: the file is still served
        # by the self-hosted resolver, and the next restart re-pushes.
        log("ERROR pushing to resolver: %s" % exc)


def _on_sigterm(signum, _frame):
    """Terminate the sshx child cleanly on SIGTERM (systemd stop/restart)."""
    log("received signal %d, terminating sshx" % signum)
    with _child_lock:
        if _child is not None and _child.poll() is None:
            try:
                _child.terminate()
            except ProcessLookupError:
                pass
    # Do not exit here: main() is waiting on the child and will exit with its
    # code once it dies, which is what systemd expects.


def main():
    global _child
    import subprocess

    if not (os.path.isfile(SSHX_BIN) and os.access(SSHX_BIN, os.X_OK)):
        log("ERROR: sshx not found/executable at '%s' (set SSHX_BIN)" % SSHX_BIN)
        return 127

    extra = shlex.split(os.environ.get("SSHX_EXTRA_ARGS", ""))
    cmd = [SSHX_BIN, "-q"]
    # Serve a native tmux client by default (faithful, interactive, lossless). Skip if the caller
    # already set --shell in SSHX_EXTRA_ARGS, if SSHX_SHELL is empty, or if the wrapper is missing.
    if "--shell" not in extra and SSHX_SHELL and os.path.isfile(SSHX_SHELL):
        cmd += ["--shell", SSHX_SHELL]
    cmd += extra
    log("starting %s" % " ".join(shlex.quote(c) for c in cmd))

    # Capture stdout so we can read the URL; sshx -q prints ONLY the URL there.
    # stderr -> our stderr (journal). Line-buffered text mode for prompt reads.
    with _child_lock:
        _child = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=None,
            text=True,
            bufsize=1,
        )

    signal.signal(signal.SIGTERM, _on_sigterm)
    signal.signal(signal.SIGINT, _on_sigterm)

    # Read sshx's stdout line by line. The first URL line is the editor URL we
    # publish; with --enable-readers a second (reader) URL may follow, which we
    # leave in stdout drain but do not publish (the file holds the editor URL).
    published = False
    try:
        for line in _child.stdout:
            m = _URL_RE.search(line)
            if m and not published:
                url = m.group(0)
                log("captured session url %s" % resolver_client.redact(url))
                publish(url)
                published = True
            # Keep draining stdout so sshx never blocks on a full pipe.
    except Exception as exc:  # noqa: BLE001
        log("ERROR reading sshx stdout: %s" % exc)

    if not published:
        log("WARNING: sshx exited before printing a session URL")

    code = _child.wait()
    log("sshx exited with code %d" % code)
    # Exit with sshx's code so Restart=always respawns on failure.
    return code


if __name__ == "__main__":
    sys.exit(main())
