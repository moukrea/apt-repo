#!/bin/sh
# install.sh - idempotent installer for the host side (units + helpers).
#
# Safe to re-run. It copies the host-core scripts and the config, installs the
# systemd USER units, enables linger, reloads, and enables the always-on units
# (tmux-server, sshx, resolver). It does NOT enable the optional rotation timer
# and it does NOT install the sleep hook (that needs root); it prints the exact
# next steps for both.
#
# It does NOT create the .py files; host-core owns sshx_spawn.py,
# resolver_client.py and sshx-url-server.py. This installer only copies whichever
# of them are present next to it.

set -eu

# Resolve the directory this script lives in (POSIX, no realpath dependency).
SRC_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

BIN_DIR="${HOME}/.local/bin"
CONF_DIR="${HOME}/.config/sshx"
UNIT_DIR="${HOME}/.config/systemd/user"
SLEEP_STAGE="${CONF_DIR}/sshx-restart.sleephook"
SLEEP_DEST="/usr/lib/systemd/system-sleep/sshx-restart"

log() { printf '[install] %s\n' "$1"; }

# Copy a file only if it exists in SRC_DIR. Overwrites the destination (managed
# files). Used for scripts and units.
copy_managed() {
    src="${SRC_DIR}/$1"
    dst="$2"
    if [ -f "$src" ]; then
        cp -- "$src" "$dst"
        log "installed $1 -> $dst"
    else
        log "skip (absent) $1"
    fi
}

# Copy a file only if the destination does NOT already exist, to preserve a
# user-edited config across re-runs. Used for resolver.env.
copy_keep_existing() {
    src="${SRC_DIR}/$1"
    dst="$2"
    if [ ! -f "$src" ]; then
        log "skip (absent) $1"
        return
    fi
    if [ -e "$dst" ]; then
        log "keep existing $dst (not overwritten)"
    else
        cp -- "$src" "$dst"
        log "installed $1 -> $dst"
    fi
}

# 1. Directories (idempotent: -p never errors if present).
mkdir -p -- "$BIN_DIR" "$CONF_DIR" "$UNIT_DIR" "${HOME}/.local/share/sshx"

# 2. Host-core scripts + CLI helpers to ~/.local/bin (copied if present, made executable).
copy_managed sshx_spawn.py        "${BIN_DIR}/sshx_spawn.py"
copy_managed resolver_client.py   "${BIN_DIR}/resolver_client.py"
copy_managed sshx_health.py       "${BIN_DIR}/sshx_health.py"
copy_managed sshx-url-server.py   "${BIN_DIR}/sshx-url-server.py"
copy_managed sshx-qr              "${BIN_DIR}/sshx-qr"
copy_managed sshx-desk            "${BIN_DIR}/sshx-desk"
copy_managed sshx-session         "${BIN_DIR}/sshx-session"
copy_managed sshx-resolver-setup  "${BIN_DIR}/sshx-resolver-setup"
copy_managed sshx-tmux-shell      "${BIN_DIR}/sshx-tmux-shell"
copy_managed sshx-tmux-bridge     "${BIN_DIR}/sshx-tmux-bridge"
copy_managed sshx-cmkey           "${BIN_DIR}/sshx-cmkey"
copy_managed sshx-da-filter       "${BIN_DIR}/sshx-da-filter"
for f in sshx_health.py sshx-url-server.py sshx-qr sshx-desk sshx-session sshx-resolver-setup sshx-tmux-shell sshx-tmux-bridge sshx-cmkey sshx-da-filter; do
    [ -f "${BIN_DIR}/${f}" ] && chmod +x "${BIN_DIR}/${f}" || true
done

# 3. Config to ~/.config/sshx. tmux.sshx.conf is managed. resolver.env: kept if already present;
#    otherwise GENERATED with a fresh random MantleDB non-claim namespace (the DEFAULT backend) so
#    each host gets its own secret - a static shipped namespace would be shared and not secret.
copy_managed tmux.sshx.conf "${CONF_DIR}/tmux.sshx.conf"
if [ -f "${CONF_DIR}/resolver.env" ]; then
    log "keep existing ${CONF_DIR}/resolver.env (not overwritten)"
elif [ -x "${BIN_DIR}/sshx-resolver-setup" ]; then
    "${BIN_DIR}/sshx-resolver-setup" --env "${CONF_DIR}/resolver.env" --no-restart --no-qr \
        && log "generated ${CONF_DIR}/resolver.env (MantleDB non-claim, fresh namespace)" \
        || log "could not generate resolver.env; edit it manually (see resolver.env.example)"
else
    copy_keep_existing resolver.env "${CONF_DIR}/resolver.env"
fi

# 3b. Route `claude` through the sshx tmux so the session is reachable from the phone. Install the
#     helper and source it from ~/.bashrc once (idempotent via a marker; never duplicated on re-run).
copy_managed claude-tmux.sh "${CONF_DIR}/claude-tmux.sh"
BASHRC="${HOME}/.bashrc"
CLAUDE_MARKER="# >>> sshx-mobile claude-tmux >>>"
if [ -f "$BASHRC" ] && grep -qF "$CLAUDE_MARKER" "$BASHRC"; then
    log "claude-tmux already sourced from ${BASHRC}"
else
    {
        printf '\n%s\n' "$CLAUDE_MARKER"
        printf '%s\n' '[ -f "$HOME/.config/sshx/claude-tmux.sh" ] && . "$HOME/.config/sshx/claude-tmux.sh"'
        printf '%s\n' "# <<< sshx-mobile claude-tmux <<<"
    } >> "$BASHRC"
    log "added claude-tmux source line to ${BASHRC}"
fi

# 3c. Ensure ~/.local/bin (where the helpers land) is on PATH for interactive shells, so `sshx-qr`,
#     `sshx-desk` etc. are runnable after setup. Distro defaults only add it on login if it already
#     existed at login time, so a first-time install would otherwise leave them "not found".
LOCALBIN_MARKER="# >>> sshx-mobile local-bin PATH >>>"
if [ -f "$BASHRC" ] && grep -qF "$LOCALBIN_MARKER" "$BASHRC"; then
    log "~/.local/bin PATH line already in ${BASHRC}"
else
    {
        printf '\n%s\n' "$LOCALBIN_MARKER"
        printf '%s\n' 'case ":$PATH:" in *":$HOME/.local/bin:"*) ;; *) PATH="$HOME/.local/bin:$PATH" ;; esac'
        printf '%s\n' "# <<< sshx-mobile local-bin PATH <<<"
    } >> "$BASHRC"
    log "added ~/.local/bin to PATH in ${BASHRC}"
fi

# 4. systemd user units (all managed: overwritten on every run).
copy_managed tmux-server.service  "${UNIT_DIR}/tmux-server.service"
copy_managed sshx.service         "${UNIT_DIR}/sshx.service"
copy_managed sshx-resolver.service "${UNIT_DIR}/sshx-resolver.service"
copy_managed sshx-tmux-bridge.service "${UNIT_DIR}/sshx-tmux-bridge.service"
copy_managed sshx-rotate.service  "${UNIT_DIR}/sshx-rotate.service"
copy_managed sshx-rotate.timer    "${UNIT_DIR}/sshx-rotate.timer"

# 5. Stage the sleep hook with the current user baked in (root install step is
#    printed below; we do not touch /usr/lib here).
if [ -f "${SRC_DIR}/system-sleep/sshx-restart" ]; then
    sed "s/__SSHX_USER__/${USER}/g" "${SRC_DIR}/system-sleep/sshx-restart" > "$SLEEP_STAGE"
    chmod +x "$SLEEP_STAGE"
    log "staged sleep hook -> $SLEEP_STAGE (user: ${USER})"
else
    log "skip (absent) system-sleep/sshx-restart"
fi

# 6. Linger so the user manager (and thus tmux + sshx) runs outside a login
#    session (idempotent: re-enabling is a no-op).
if loginctl enable-linger "$USER" 2>/dev/null; then
    log "linger enabled for ${USER}"
else
    log "could not enable linger (continuing); run: loginctl enable-linger ${USER}"
fi

# 7. Reload the user manager and enable the always-on units. enable --now is
#    idempotent. The optional rotation timer is intentionally NOT enabled.
systemctl --user daemon-reload
log "daemon-reload done"

# 6b. Ensure the `sshx` CLI is present. It is NOT a distro package (it ships from sshx.io); the
#     official installer drops it at /usr/local/bin/sshx, which is exactly sshx.service's default
#     SSHX_BIN and is on the systemd --user PATH. Offer to install it so setup completes in one go.
#     Set SSHX_AUTO_INSTALL=0 to never auto-install. If sshx ends up missing we SKIP starting
#     sshx.service (so it does not crash-loop) and tell the user how to finish.
SSHX_PATH="${SSHX_BIN:-}"
[ -z "$SSHX_PATH" ] && SSHX_PATH="$(command -v sshx 2>/dev/null || true)"
[ -z "$SSHX_PATH" ] && [ -x /usr/local/bin/sshx ] && SSHX_PATH=/usr/local/bin/sshx
if [ -z "$SSHX_PATH" ]; then
    log "sshx CLI not found (required to serve the session)."
    if [ "${SSHX_AUTO_INSTALL:-1}" = "1" ] && [ -t 0 ] && command -v curl >/dev/null 2>&1; then
        printf '[install] Install sshx now from https://sshx.io? [Y/n] '
        _ans=y; read -r _ans </dev/tty 2>/dev/null || _ans=y
        case "$_ans" in
            [Nn]*) log "skipped sshx install" ;;
            *) curl -fsSL https://sshx.io/get | sh || log "sshx install failed (install it manually)" ;;
        esac
        SSHX_PATH="$(command -v sshx 2>/dev/null || true)"
        [ -z "$SSHX_PATH" ] && [ -x /usr/local/bin/sshx ] && SSHX_PATH=/usr/local/bin/sshx
    fi
fi

systemctl --user enable --now tmux-server.service
# The self-hosted resolver server is only needed for the self-hosted profile. The DEFAULT is
# MantleDB (push goes straight to MantleDB), so only start sshx-resolver when resolver.env points
# its push URL at loopback. Avoids running an unused HTTP server on the MantleDB default.
if grep -qE '^RESOLVER_PUSH_URL=https?://(localhost|127\.0\.0\.1)(:|/)' "${CONF_DIR}/resolver.env" 2>/dev/null; then
    systemctl --user enable --now sshx-resolver.service
    log "enabled tmux-server, sshx-resolver (self-hosted profile), sshx"
else
    systemctl --user disable --now sshx-resolver.service 2>/dev/null || true
    log "enabled tmux-server, sshx (MantleDB/external resolver: sshx-resolver NOT started)"
fi
if [ -n "$SSHX_PATH" ]; then
    systemctl --user enable --now sshx.service
    log "enabled sshx.service (sshx: ${SSHX_PATH})"
else
    log "WARNING: sshx not installed - NOT starting sshx.service (it would crash-loop)."
    log "  Install sshx:  curl -sSf https://sshx.io/get | sh"
    log "  Then run:      systemctl --user enable --now sshx.service   (or re-run sshx-host-setup)"
fi
# The bridge publishes the tmux window list to the resolver's /windows sibling. The app polls it and
# auto-creates a tab per window, so sessions opened ON THE HOST (e.g. the `claude` helper) appear as
# tabs automatically - both live and on reopen. (Tab SWITCHING stays local/instant; only the window
# LIST is out-of-band.) It republishes only when the window set changes.
systemctl --user enable --now sshx-tmux-bridge.service 2>/dev/null || true
log "enabled sshx-tmux-bridge (publishes the window list for the app's auto-tab sync)"

# Print the pairing QR now so the user can scan it immediately. `sshx-qr` with no args renders the
# RESOLVER QR (valid as soon as resolver.env exists - it encodes where the app polls, not the live
# session), so it works even before sshx is installed. Full path: ~/.local/bin may not be on PATH in
# this very shell.
if [ -x "${BIN_DIR}/sshx-qr" ]; then
    printf '\n[install] ==== Scan this in the sshx-mobile app (Scan QR) ====\n\n'
    "${BIN_DIR}/sshx-qr" 2>/dev/null || log "could not render the QR now; run 'sshx-qr' after re-login"
    printf '\n'
fi

# 8. Next steps that this script cannot do (root) or should not do by default.
cat <<EOF

[install] Done. Always-on units are enabled and started.

Next steps (manual):

  1) Sleep hook (needs root, restarts sshx on wake, lossless):
       sudo cp "${SLEEP_STAGE}" "${SLEEP_DEST}"
       sudo chmod +x "${SLEEP_DEST}"

  2) URL rotation (OPTIONAL, hourly, lossless). Disabled by default:
       systemctl --user enable --now sshx-rotate.timer

  3) Resolver: a fresh MantleDB non-claim namespace was generated. To re-roll it, switch
     backend, or add write-protection (claim, no email), run:
       sshx-resolver-setup            # non-claim MantleDB (default)
       sshx-resolver-setup --claim    # + claim the namespace for write-protection

  4) Phone: show the QR to scan once (auto-fills the app's resolver fields):
       sshx-qr                        # auto: resolver QR when a resolver is configured
       sshx-qr --current              # or the current running session, one-off

  5) Desktop co-access (normal client, shares the windows):
       sshx-desk                      # = tmux -L sshx new-session -t main -s desk

Check status:
  systemctl --user status tmux-server sshx sshx-resolver
  journalctl --user -u sshx -f
EOF
