# sshx mobile - host tooling

Tools for the machine that runs `sshx`, so a phone (the **sshx mobile** Android
app, see [`../android/README.md`](../android/README.md)) can connect, scan a QR,
and survive network changes / process restarts.

For the full lossless remote-access system (tmux persistence + resolver + auto
reconnect), see [`../docs/setup-host.md`](../docs/setup-host.md),
[`../docs/runbook.md`](../docs/runbook.md) and the ADRs in `../docs/adr/`. Install
everything with [`install.sh`](./install.sh).

| File | What it is |
|---|---|
| [`install.sh`](./install.sh) | Idempotent installer: lays down scripts, config and user units, enables linger. |
| [`sshx_spawn.py`](./sshx_spawn.py) | Spawns disposable `sshx`, captures the URL, pushes it to the resolver, waits. Also runs the liveness self-heal. Run by `sshx.service`. |
| [`resolver_client.py`](./resolver_client.py) | Backend-agnostic resolver push/read (MantleDB or self-hosted), see ADR 0001. |
| [`sshx_health.py`](./sshx_health.py) | Liveness probe: WebSockets to `/api/s/<id>` and reads the first frame (close 4404 = dead, Hello = alive). No `#key`, no user registered. Used by the self-heal; runnable standalone. |
| [`sshx-url-server.py`](./sshx-url-server.py) | Self-hosted resolver: `POST /current-url` (host pushes) and `GET /current-url` (phone reads). |
| [`tmux-server.service`](./tmux-server.service) | Isolated tmux server (socket `sshx`), separate cgroup so it survives `sshx` restarts. |
| [`sshx.service`](./sshx.service) | User unit running `sshx_spawn.py` (`Restart=always`); the disposable pipe. |
| [`sshx-rotate.timer`](./sshx-rotate.timer) | Optional hourly rotation (restarts `sshx`, lossless). Off by default. |
| [`sshx-resolver.service`](./sshx-resolver.service) | Runs the self-hosted resolver over your trusted network. |
| [`tmux.sshx.conf`](./tmux.sshx.conf) | Dedicated tmux config (window-size latest, history-limit 20000, etc). |
| [`sshx-desk`](./sshx-desk) | Desktop co-access: attaches as a NORMAL grouped client (`tmux -L sshx`). |
| [`sshx-mouse`](./sshx-mouse) | Flip tmux mouse for the current desktop session: ON = wheel scrolls (Shift+drag selects natively); OFF = plain drag selects (wheel sends arrows). Phone tabs (`sx*`) are always mouse-off. Run inside a `sshx-desk`/`claude` window. |
| [`claude-tmux.sh`](./claude-tmux.sh) | Sourced from `~/.bashrc`: runs `claude <args>` in a `main` window marked with a host view session (`hx<id>`) and attaches the current terminal. The phone's `sshx-tmux-shell` co-views that window (a new tab shows the SAME claude session), so you interact with it from either side. Exits back to your shell when claude exits (reaper); survives in tmux if you just detach. Creates a configured server on demand if none is running. |
| [`system-sleep/sshx-restart`](./system-sleep/sshx-restart) | Sleep hook: restart `sshx` on resume. |
| [`sshx-qr`](./sshx-qr) | Print a QR for a URL, generated **strictly locally**. |
| [`sshx-session`](./sshx-session) | Older tmux-based single-session launcher (kept for ad hoc use). |

---

## ⚠️ Privacy: the `#key` is your end-to-end encryption key

An sshx session URL looks like:

```
https://sshx.io/s/UuWX4sOSrm#dmGcdlAyGfkrMf
                            └──────┬───────┘
                              the #fragment
```

Everything after `#` is the **end-to-end decryption key**. sshx consumes it in
the browser; it is **never sent to the sshx server**. Anyone who has the full
URL can read and type in your terminal.

Therefore:

- **`sshx-qr` never transmits the URL.** Every QR backend encodes the URL as
  literal QR data **offline** - no network call. Do **not** paste sshx URLs into
  online QR generators; that leaks your key.
- **The resolver serves the URL in plaintext** and must be reached **only over
  infrastructure you control** - LAN, Tailscale, or WireGuard. Never expose it to
  the public internet, a public Gist/Pastebin, or a webhook.

---

## Quick start (QR)

Start a session and show a scannable QR in your terminal:

```bash
./sshx-qr
```

`sshx-qr` launches `sshx -q`, captures the printed URL, and renders the QR
locally. Scan it with the **sshx mobile** app (it uses CameraX + ML Kit; the
scanned string is normalized and opened). `sshx` keeps running in the foreground
- `Ctrl-C` ends the session.

Render a QR for a URL you already have (no new session):

```bash
./sshx-qr https://sshx.io/s/UuWX4sOSrm#dmGcdlAyGfkrMf
./sshx-qr --url https://sshx.io/s/UuWX4sOSrm#dmGcdlAyGfkrMf
```

Useful flags (all passed through to `sshx` where relevant):

```bash
./sshx-qr --name "demo-box"          # session title
./sshx-qr --shell /bin/bash          # local shell to run
./sshx-qr --enable-readers           # also mint a read-only viewer URL
./sshx-qr --png /tmp/session.png     # also write a PNG (qrencode/segno backend)
```

### QR backend - self-bootstrapping

`sshx-qr` tries, in order, the first backend that works:

1. **`qrencode`** - `qrencode -t ANSIUTF8 -l M` (+ PNG with `-s 8`).
2. **`python3` + `segno`** - pure-python, zero non-stdlib deps; `terminal(compact=True)` (+ `qr.save(png, scale=8)`).
3. **`python3` + `qrcode`** - `print_ascii()` (PNG needs `pillow`).
4. **auto `pip install --user segno`**, then retry (2).
5. else print the URL + an install hint and exit non-zero.

Install any one ahead of time if you like:

```bash
sudo apt install qrencode        # or: brew install qrencode
pip install --user segno         # pure-python, recommended
```

---

## Keeping the session alive

`sshx`'s own reconnect loop survives **network changes** (WiFi ⇄ 4G, IP changes)
**without minting a new URL** - a phone that already holds the URL just waits
through the outage and reconnects. What you need to survive is the **process**.

### A new URL is minted only on process restart

There is **no session-id pinning flag** in `sshx`. Every time the process
(re)starts it mints a **new** URL; the old one is dead. The session is also
garbage-collected by the server after the host is unreachable for **> 5 minutes**.
So:

- Plan for the URL to change across restarts.
- Either re-scan the QR after a restart, **or** use the optional **resolver**
  (below) so the phone re-resolves the current URL automatically.

### Self-heal: a stale session is detected and re-minted automatically

`sshx`'s reconnect loop survives clean network changes, but it can be left
holding a **dead** session: if the host is unreachable for > 5 minutes the server
garbage-collects the session, and after a suspend or a half-open TCP the local
`sshx` may keep a wedged connection without exiting - so it never re-mints a URL,
the resolver keeps serving the dead one, and the app shows a blank screen.

`sshx_spawn.py` runs a background **liveness monitor** ([`sshx_health.py`](./sshx_health.py))
that probes the live session exactly the way the phone does (a WebSocket to
`/api/s/<id>`): a close frame with code **4404** means the server has forgotten
the session. After a couple of consecutive dead verdicts it terminates `sshx`,
and `Restart=always` respawns it - minting a fresh URL and re-pushing it to the
resolver. The phone re-resolves and reconnects within seconds, **no re-scan**.
The probe sends no `#key` and registers no user, so it is invisible to other
clients. This works **with rotation off**; rotation is now only a belt-and-braces
exposure-window limiter, not the staleness fix.

Tunables (environment, e.g. in `sshx.service` via `Environment=` or
`resolver.env`):

| Var | Default | Meaning |
|---|---|---|
| `SSHX_HEALTH_INTERVAL` | `30` | Seconds between probes. `0` disables the self-heal. |
| `SSHX_HEALTH_GRACE` | `20` | Delay after a session is minted before the first probe. |
| `SSHX_HEALTH_FAILS` | `2` | Consecutive dead verdicts required before restarting. |
| `SSHX_HEALTH_KILL_GRACE` | `5` | Seconds to wait for `sshx` to exit on SIGTERM before SIGKILL. |

```bash
python3 ~/.local/bin/sshx_health.py "$(cat ~/.local/share/sshx/current-url)"   # alive | dead | unknown
journalctl --user -u sshx | grep health                                        # what the monitor did
```

### Option A - systemd user unit (recommended)

```bash
mkdir -p ~/.config/systemd/user
cp sshx.service ~/.config/systemd/user/sshx.service
loginctl enable-linger "$USER"        # keep your user manager running after logout
systemctl --user daemon-reload
systemctl --user enable --now sshx
```

- `Restart=on-failure`, `RestartSec=5s` → the session respawns if `sshx` crashes
  (minting a new URL).
- The current URL is at `~/.local/share/sshx/current-url`.

```bash
cat ~/.local/share/sshx/current-url      # current URL
./sshx-qr --url "$(cat ~/.local/share/sshx/current-url)"
systemctl --user status sshx
journalctl --user -u sshx -f
```

### Option B - tmux launcher (`sshx-session`)

For hosts without `systemd --user` / lingering, or for a quick detached session:

```bash
./sshx-session start --name "demo-box"   # starts in detached tmux, prints URL + QR
./sshx-session url                        # current URL
./sshx-session qr                         # re-print the QR
./sshx-session status
./sshx-session restart                    # MINTS A NEW URL
./sshx-session stop                       # ends the session (kills the URL)
```

It writes the URL to the **same** file (`~/.local/share/sshx/current-url`), so the
resolver works with either option.

---

## Optional stable alias: the resolver (so the phone re-resolves after a restart)

Because the URL changes on restart, you can run a tiny resolver that always serves
the **current** URL at a **stable** address. The phone holds the *resolver* URL
(stable) and fetches the *session* URL (changing) from it.

```bash
# Put the server somewhere on the host:
mkdir -p ~/.local/bin
cp sshx-url-server.py ~/.local/bin/sshx-url-server.py
chmod +x ~/.local/bin/sshx-url-server.py

cp sshx-resolver.service ~/.config/systemd/user/sshx-resolver.service
systemctl --user daemon-reload
systemctl --user enable --now sshx-resolver
```

It serves:

```
GET http://<host>:8765/current-url   ->  the current sshx URL (plaintext, Cache-Control: no-store)
```

It reads the file **fresh per request**, so after `sshx.service` restarts and
mints a new URL, the next fetch returns the new one - **no re-scan needed**.

### Privacy trade-off: where the `#key` lives

The resolver returns the **full URL including the `#key`** in **plaintext**. That
is acceptable **only** if the request never leaves a network you control:

- ✅ **Tailscale MagicDNS (most robust stable alias):**
  `http://<host>.<tailnet>.ts.net:8765/current-url` - a stable name that follows
  the host anywhere, traffic encrypted by WireGuard inside the tailnet.
- ✅ **LAN / WireGuard:** `http://192.168.x.y:8765/current-url` on your own subnet,
  or a WireGuard peer address.
- ❌ **Never** a public IP, port-forward to the internet, public Gist/Pastebin, or
  a webhook. That would publish your E2E key to a third party - the whole point of
  end-to-end encryption is then lost.

To restrict the bind address to a Tailscale IP, set `SSHX_RESOLVER_BIND`:

```bash
systemctl --user edit sshx-resolver
# [Service]
# Environment=SSHX_RESOLVER_BIND=100.x.y.z
```

### Phone side

In the **sshx mobile** app, set the optional **Resolver URL** to the stable
address above. The app:

- `GET`s the resolver URL, runs the response through the same URL normalizer, then
  loads the session;
- re-fetches on a WebView connection error or a manual refresh - so after a host
  restart you just pull-to-refresh instead of re-scanning a QR.

The app's `network_security_config.xml` permits cleartext **only** for RFC-1918
(LAN) and `*.ts.net` (Tailscale) hosts for exactly this fetch; `sshx` itself stays
HTTPS-only.
